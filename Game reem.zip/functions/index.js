
const {onCall, HttpsError} = require("firebase-functions/v2/https");
const {setGlobalOptions} = require("firebase-functions/v2/options");
const {defineSecret} = require("firebase-functions/params");
const {getDatabase, ServerValue} = require("firebase-admin/database");
const {initializeApp} = require("firebase-admin/app");
const crypto = require("crypto");
const {QUESTIONS} = require("./questions");

initializeApp();
setGlobalOptions({region:"us-central1", maxInstances:10, memory:"256MiB"});
const ADMIN_PIN = defineSecret("ADMIN_PIN");
const db = getDatabase();

function fail(code,message){throw new HttpsError(code,message)}
function normalizeArabic(input=""){
  return String(input).trim().toLowerCase()
    .normalize("NFKC")
    .replace(/[\u064B-\u065F\u0670\u06D6-\u06ED]/g,"")
    .replace(/[أإآٱ]/g,"ا").replace(/ى/g,"ي").replace(/ؤ/g,"و").replace(/ئ/g,"ي").replace(/ة/g,"ه")
    .replace(/ـ/g,"").replace(/\s+/g," ").trim();
}
function uidRequired(req){if(!req.auth)fail("unauthenticated","يجب الاتصال بحساب مجهول في Firebase.");return req.auth.uid}
function adminCheck(req,pin){
  uidRequired(req);
  if(!pin || pin !== ADMIN_PIN.value()) fail("permission-denied","رمز المنظم غير صحيح.");
}
function tokenForTeam(game,team,token){return game?.teams?.[team]?.token && game.teams[team].token===token}
function randomToken(){return crypto.randomBytes(18).toString("base64url")}
function allQuestions(game){return [...QUESTIONS,...(Array.isArray(game.customQuestions)?game.customQuestions:[])];}
function chooseQuestion(used,difficulty,game){
  let pool=allQuestions(game).filter(q=>!used.includes(q.id));
  if(difficulty && difficulty!=="mixed"){const filtered=pool.filter(q=>q.difficulty===difficulty);if(filtered.length>=1)pool=filtered;}
  if(!pool.length)return null;
  return pool[Math.floor(Math.random()*pool.length)];
}
function questionPublic(q){
  return {id:q.id,question:q.question,category:q.category,difficulty:q.difficulty,requiredAnswers:q.requiredAnswers};
}
function blankTeam(token){return {token,correctCount:0,answers:{},members:0}}
function freshRound(game,now){
  const used=Array.isArray(game.usedQuestions)?game.usedQuestions:[];
  const q=chooseQuestion(used,game.config.difficulty,game);
  if(!q) return null;
  const starter=game.round%2===1?"blue":"red";
  return {
    ...game,
    phase:"running",
    roundStartedAt:now,
    deadlineAt:now+game.config.roundSeconds*1000,
    remainingMs:null,
    winnerTeam:null,
    winnerAt:null,
    winnerElapsedMs:null,
    stealTeam:null,
    starterTeam:starter,
    question:questionPublic(q),
    usedQuestions:[...used,q.id],
    teams:{blue:{...blankTeam(game.teams.blue.token)},red:{...blankTeam(game.teams.red.token)}}
  };
}

exports.createGame = onCall({secrets:[ADMIN_PIN]}, async (req)=>{
  adminCheck(req,req.data?.adminPin);
  const c=req.data?.config||{};
  const config={
    blueName:String(c.blueName||"الفريق الأول").slice(0,30),
    redName:String(c.redName||"الفريق الثاني").slice(0,30),
    blueColor:String(c.blueColor||"#2f80ff"),
    redColor:String(c.redColor||"#ff4d5f"),
    rounds:Math.max(1,Math.min(50,Number(c.rounds)||5)),
    roundSeconds:[15,20,30,45,60].includes(Number(c.roundSeconds))?Number(c.roundSeconds):30,
    stealSeconds:[5,8,10,15].includes(Number(c.stealSeconds))?Number(c.stealSeconds):8,
    difficulty:["easy","medium","hard","mixed"].includes(c.difficulty)?c.difficulty:"mixed",
    sound:Boolean(c.sound)
  };
  const gameId=crypto.randomBytes(6).toString("hex");
  const now=Date.now();
  const game={version:1,gameId,phase:"lobby",createdAt:now,updatedAt:now,round:0,scores:{blue:0,red:0},usedQuestions:[],winnerTeam:null,question:null,starterTeam:null,roundStartedAt:null,deadlineAt:null,remainingMs:null,customQuestions:[],config,teams:{blue:blankTeam(randomToken()),red:blankTeam(randomToken())}};
  await db.ref(`games/${gameId}`).set(game);
  return {gameId};
});

exports.adminCommand = onCall({secrets:[ADMIN_PIN]}, async (req)=>{
  adminCheck(req,req.data?.adminPin);
  const {gameId,action}=req.data||{};
  if(!gameId)fail("invalid-argument","gameId مفقود.");
  const r=db.ref(`games/${gameId}`);
  const result=await r.transaction(game=>{
    if(!game)return;
    const now=Date.now();
    if(action==="start"||action==="next"){
      if(action==="start" && !["lobby","round_over"].includes(game.phase))return game;
      if(action==="next" && !["lobby","round_over"].includes(game.phase))return game;
      if(game.round>=game.config.rounds)return {...game,phase:"finished"};
      const next={...game,round:game.round+1};
      return freshRound(next,now);
    }
    if(action==="pause"){
      if(game.phase!=="running")return game;
      return {...game,phase:"paused",remainingMs:Math.max(0,game.deadlineAt-now),deadlineAt:null,updatedAt:now};
    }
    if(action==="resume"){
      if(game.phase!=="paused")return game;
      return {...game,phase:"running",deadlineAt:now+Math.max(0,game.remainingMs||0),remainingMs:null,updatedAt:now};
    }
    if(action==="resetRound"){
      if(!game.question)return game;
      const used=Array.isArray(game.usedQuestions)?game.usedQuestions:[];
      const q=allQuestions(game).find(x=>x.id===game.question.id);
      if(!q)return game;
      return {...game,phase:"running",roundStartedAt:now,deadlineAt:now+game.config.roundSeconds*1000,remainingMs:null,winnerTeam:null,winnerAt:null,winnerElapsedMs:null,stealTeam:null,question:questionPublic(q),teams:{blue:blankTeam(game.teams.blue.token),red:blankTeam(game.teams.red.token)},updatedAt:now};
    }
    if(action==="skip"){
      if(!["running","paused","steal"].includes(game.phase))return game;
      return {...game,phase:"round_over",deadlineAt:null,remainingMs:null,updatedAt:now};
    }
    if(action==="endRound"){
      if(!["running","paused","steal"].includes(game.phase))return game;
      return {...game,phase:"round_over",deadlineAt:null,remainingMs:null,updatedAt:now};
    }
    if(action==="addQuestion"){
      if(game.phase!=="lobby") fail("failed-precondition","أضف الأسئلة قبل بدء اللعبة.");
      const q=req.data?.question;
      if(!q || typeof q.question!=="string" || !Array.isArray(q.acceptedAnswers)) fail("invalid-argument","بيانات السؤال غير مكتملة.");
      const answers=[...new Set(q.acceptedAnswers.map(x=>String(x).trim()).filter(Boolean))];
      if(answers.length<5) fail("invalid-argument","يجب إدخال 5 إجابات مقبولة على الأقل.");
      const ids=allQuestions(game).map(x=>Number(x.id)).filter(Number.isFinite);
      const id=Math.max(0,...ids)+1;
      const custom={id,question:q.question.trim().slice(0,180),category:String(q.category||"مخصص").slice(0,40),difficulty:["easy","medium","hard"].includes(q.difficulty)?q.difficulty:"medium",requiredAnswers:5,acceptedAnswers:answers.slice(0,80)};
      return {...game,customQuestions:[...(game.customQuestions||[]),custom],updatedAt:Date.now()};
    }
    if(action==="updateQuestion"){
      if(game.phase!=="lobby") fail("failed-precondition","عدّل الأسئلة قبل بدء اللعبة.");
      const id=Number(req.data?.question?.id), old=(game.customQuestions||[]).find(x=>x.id===id);
      if(!old) fail("not-found","السؤال المخصص غير موجود.");
      const q=req.data.question,answers=[...new Set((q.acceptedAnswers||[]).map(x=>String(x).trim()).filter(Boolean))];
      if(answers.length<5) fail("invalid-argument","يجب إدخال 5 إجابات مقبولة على الأقل.");
      const updated={...old,question:String(q.question||old.question).trim().slice(0,180),category:String(q.category||old.category).slice(0,40),difficulty:["easy","medium","hard"].includes(q.difficulty)?q.difficulty:old.difficulty,acceptedAnswers:answers.slice(0,80)};
      return {...game,customQuestions:(game.customQuestions||[]).map(x=>x.id===id?updated:x),updatedAt:Date.now()};
    }
    if(action==="deleteQuestion"){
      if(game.phase!=="lobby") fail("failed-precondition","احذف الأسئلة قبل بدء اللعبة.");
      const id=Number(req.data?.questionId);
      return {...game,customQuestions:(game.customQuestions||[]).filter(x=>x.id!==id),updatedAt:Date.now()};
    }
    if(action==="adjustScore"){
      if(!["blue","red"].includes(req.data?.team)) fail("invalid-argument","الفريق غير صالح.");
      const delta=Math.max(-10,Math.min(10,Number(req.data?.delta)||0));
      return {...game,scores:{...game.scores,[req.data.team]:Math.max(0,(game.scores?.[req.data.team]||0)+delta)},updatedAt:Date.now()};
    }
    if(action==="resetGame"){
      return {version:1,gameId,phase:"lobby",createdAt:game.createdAt,updatedAt:now,round:0,scores:{blue:0,red:0},usedQuestions:[],winnerTeam:null,question:null,starterTeam:null,roundStartedAt:null,deadlineAt:null,remainingMs:null,customQuestions:game.customQuestions||[],config:game.config,teams:{blue:blankTeam(game.teams.blue.token),red:blankTeam(game.teams.red.token)}};
    }
    return game;
  });
  return {ok:true};
});

exports.advanceExpired = onCall(async (req)=>{
  uidRequired(req);
  const {gameId}=req.data||{};
  if(!gameId)fail("invalid-argument","gameId مفقود.");
  const r=db.ref(`games/${gameId}`);
  let output={changed:false};
  await r.transaction(game=>{
    if(!game)return;
    if(!["running","steal"].includes(game.phase))return game;
    const now=Date.now();
    if(now < Number(game.deadlineAt||0))return game;
    if(game.phase==="steal"){
      output={changed:true,phase:"round_over"};
      return {...game,phase:"round_over",deadlineAt:null,remainingMs:null,updatedAt:now};
    }
    const starter=game.starterTeam;
    const starterCount=game.teams?.[starter]?.correctCount||0;
    if(starterCount===game.question.requiredAnswers){
      output={changed:true,phase:"round_over",winnerTeam:starter};
      return {...game,phase:"round_over",deadlineAt:null,remainingMs:null,updatedAt:now};
    }
    if(starterCount===game.question.requiredAnswers-1){
      const stealTeam=starter==="blue"?"red":"blue";
      output={changed:true,phase:"steal",stealTeam};
      return {...game,phase:"steal",stealTeam,deadlineAt:now+game.config.stealSeconds*1000,updatedAt:now};
    }
    output={changed:true,phase:"round_over"};
    return {...game,phase:"round_over",deadlineAt:null,remainingMs:null,updatedAt:now};
  });
  return output;
});

exports.submitAnswer = onCall(async (req)=>{
  const uid=uidRequired(req);
  const {gameId,team,token,answer}=req.data||{};
  if(!gameId||!["blue","red"].includes(team)||typeof token!=="string"||typeof answer!=="string")fail("invalid-argument","بيانات الإجابة غير مكتملة.");
  const clean=answer.trim();
  if(clean.length<1||clean.length>40)fail("invalid-argument","الإجابة يجب أن تكون بين حرف واحد و40 حرفًا.");
  const r=db.ref(`games/${gameId}`);
  let response={};
  await r.transaction(game=>{
    if(!game)fail("not-found","اللعبة غير موجودة.");
    const now=Date.now();
    if(!tokenForTeam(game,team,token))fail("permission-denied","رمز الفريق غير صالح.");
    if(!["running","steal"].includes(game.phase))fail("failed-precondition","الجولة غير متاحة الآن.");
    if(now>Number(game.deadlineAt||0))fail("deadline-exceeded","انتهى وقت الإجابة.");
    if(game.phase==="steal" && game.stealTeam!==team)fail("permission-denied","هذه ليست فرصة فريقك.");
    const q=allQuestions(game).find(x=>x.id===game.question?.id);
    if(!q)fail("failed-precondition","السؤال غير موجود.");
    const norm=normalizeArabic(clean);
    if(!norm)fail("invalid-argument","الإجابة غير صالحة.");
    const t=game.teams[team];
    const answers={...(t.answers||{})};
    if(answers[norm]){
      response={correct:false,duplicate:true,message:"هذه الإجابة مكررة."};
      return game;
    }
    const accepted=new Map(q.acceptedAnswers.map(x=>[normalizeArabic(x),x]));
    const correct=accepted.has(norm);
    const rec={display:clean,normalized:norm,correct,uid,serverAt:now,elapsedMs:game.roundStartedAt?now-game.roundStartedAt:null};
    answers[norm]=rec;
    let correctCount=t.correctCount||0;
    if(correct)correctCount++;
    let next={...game,teams:{...game.teams,[team]:{...t,answers,correctCount,members:t.members||0}},updatedAt:now};
    if(correct && correctCount>=q.requiredAnswers){
      next={...next,phase:"round_over",winnerTeam:team,winnerAt:now,winnerElapsedMs:game.roundStartedAt?now-game.roundStartedAt:null,deadlineAt:null,remainingMs:null};
      next.scores={...game.scores,[team]:(game.scores?.[team]||0)+1};
      response={correct:true,winner:true,duplicate:false,elapsedMs:next.winnerElapsedMs};
    }else if(correct && game.phase==="steal"){
      next={...next,phase:"round_over",winnerTeam:team,winnerAt:now,winnerElapsedMs:game.roundStartedAt?now-game.roundStartedAt:null,deadlineAt:null,remainingMs:null};
      next.scores={...game.scores,[team]:(game.scores?.[team]||0)+1};
      response={correct:true,winner:true,stolen:true,duplicate:false};
    }else{
      response={correct,duplicate:false,message:correct?"إجابة صحيحة":"الإجابة غير موجودة في قائمة الإجابات المقبولة."};
    }
    return next;
  });
  return response;
});
