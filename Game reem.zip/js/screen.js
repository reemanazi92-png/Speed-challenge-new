
import { listenGame, ensureAuth, call } from "./firebase.js";
import { escapeHtml, formatMs } from "./common.js";

const params = new URLSearchParams(location.search);
const gameId = params.get("game");
const root = document.querySelector("#screen");
const toast = document.querySelector("#toast");
let state = null, tick, lastExpiredDeadline = 0;

function showToast(msg){toast.textContent=msg;toast.classList.add("show");setTimeout(()=>toast.classList.remove("show"),2200)}
function teamState(team){
  const t=state?.teams?.[team]; const need=state?.question?.requiredAnswers||5;
  if(!t) return {count:0,answers:[]};
  return {count:t.correctCount||0,answers:Object.values(t.answers||{})};
}
function qrUrl(team){
  const t=state?.teams?.[team]; if(!t) return "";
  return `team.html?game=${encodeURIComponent(gameId)}&team=${team}&token=${encodeURIComponent(t.token)}`;
}
function render(){
  if(!state){root.innerHTML=`<section class="hero-card glass"><span class="eyebrow">⚡ تحدي السرعة</span><h1>جاهزون؟</h1><p>بانتظار الاتصال باللعبة...</p></section>`;return;}
  if(state.phase==="finished"){
    const win=(state.scores.blue||0)>(state.scores.red||0)?"blue":(state.scores.red||0)>(state.scores.blue||0)?"red":"tie";
    const winner=win==="tie"?"تعادل!":state.config[win+"Name"];
    root.innerHTML=`<section class="hero-card glass"><div class="trophy" style="font-size:90px">🏆</div><span class="eyebrow">النتيجة النهائية</span><h1>${escapeHtml(winner)}</h1><div class="scoreboard"><div class="score blue"><span>${escapeHtml(state.config.blueName)}</span><strong>${state.scores.blue}</strong></div><div class="vs">—</div><div class="score red"><span>${escapeHtml(state.config.redName)}</span><strong>${state.scores.red}</strong></div></div><p>اضغط «إعادة ضبط اللعبة» من لوحة المنظم لبدء منافسة جديدة.</p></section>`;return;
  }
  if(state.phase==="lobby"){root.innerHTML=`<section class="hero-card glass"><span class="eyebrow">⚡ تحدي السرعة</span><h1>جاهزون؟</h1><p>امسح رمز فريقك من جوالك ثم انتظر بدء الجولة.</p><div class="waiting-dots"><span></span><span></span><span></span></div><p>الجولات: ${state.config.rounds}</p></section>`;return;}
  const blue=teamState("blue"), red=teamState("red"), need=state.question?.requiredAnswers||5;
  const winner=state.winnerTeam;
  const phaseText={running:"مباشرة",paused:"متوقفة مؤقتًا",steal:"🔥 فرصة السرقة",round_over:"انتهت الجولة",finished:"انتهت اللعبة"}[state.phase]||state.phase;
  const timerMs=state.phase==="paused"?state.remainingMs:Math.max(0,(state.deadlineAt||0)-Date.now());
  const seconds=timerMs/1000;
  const timerClass=seconds<=5?"danger":seconds<=10?"warning":"";
  root.innerHTML=`
  <div class="screen-game">
    <div class="score-row">
      <section class="team-panel glass blue"><div class="team-head"><div class="team-name">🟦 ${escapeHtml(state.config.blueName)}</div><div class="team-score">${state.scores.blue||0}</div></div><div class="qr-mini" id="qrScreenBlue"></div><p>${statusText("blue")}</p></section>
      <div class="vs-round"><div class="round-tag">${phaseText}</div><div class="round-number">الجولة ${state.round||0}</div></div>
      <section class="team-panel glass red"><div class="team-head"><div class="team-name">🟥 ${escapeHtml(state.config.redName)}</div><div class="team-score">${state.scores.red||0}</div></div><div class="qr-mini" id="qrScreenRed"></div><p>${statusText("red")}</p></section>
    </div>
    <section class="center-card glass">
      <div class="question-label">${escapeHtml(state.question?.category||"تحدي")} · ${difficultyLabel(state.question?.difficulty)}</div>
      <div class="screen-question">${escapeHtml(state.question?.question||"—")}</div>
      <div class="timer-big ${timerClass}" id="mainTimer">${state.phase==="steal"?"🔥 "+formatMs(timerMs):formatMs(timerMs)}</div>
      <div class="meter"><i id="screenMeter"></i></div>
      <div class="live-columns">
        ${feed("🟦",state.config.blueName,blue,need,"blue")}
        ${feed("🟥",state.config.redName,red,need,"red")}
      </div>
    </section>
  </div>`;
  if(window.QRCode){for(const team of ["blue","red"]){const box=document.querySelector("#qrScreen"+(team==="blue"?"Blue":"Red"));if(box){box.innerHTML="";new QRCode(box,{text:qrUrl(team),width:75,height:75,colorDark:"#101625",colorLight:"#ffffff",correctLevel:QRCode.CorrectLevel.M});}}}
  if(winner){ showWinner(winner); }
}
function difficultyLabel(d){return d==="easy"?"🟢 سهل":d==="medium"?"🟡 متوسط":d==="hard"?"🔴 صعب":"🔥 مختلط"}
function statusText(team){
  const t=state.teams[team]; const c=t?.correctCount||0;
  if(state.winnerTeam===team)return "🏆 فاز";
  if(state.phase==="steal" && state.stealTeam===team)return "🔥 يحاول السرقة";
  if(state.phase==="running")return c?`🔵 ${c} / ${state.question.requiredAnswers}`:"🟢 يجيب الآن";
  if(state.phase==="paused")return "⏸️ متوقفة مؤقتًا";
  return state.phase==="round_over"?"❌ انتهى الوقت":"🟢 في الانتظار";
}
function feed(icon,name,t,need){
  const answers=Object.values(t.answers||{});
  return `<div class="answer-feed"><div class="feed-title"><span>${icon} ${escapeHtml(name)}</span><b>${t.correctCount||0} / ${need}</b></div><div class="feed-items">${answers.slice(-8).map(a=>`<span class="answer-chip ${a.correct?"good":"bad"}">${a.correct?"✅":"❌"} ${escapeHtml(a.display||a.normalized)}</span>`).join("")||"<span class='answer-chip'>بانتظار أول إجابة…</span>"}</div></div>`
}
function showWinner(team){
  if(document.querySelector(".winner-overlay"))return;
  const name=state.config[team+"Name"];
  const overlay=document.createElement("div");overlay.className="winner-overlay";
  overlay.innerHTML=`<div class="winner-box glass"><div class="trophy">🏆</div><div class="question-label">الفائز في الجولة</div><h1>${escapeHtml(name)}</h1><p>نتيجة الجولة ${state.round}: ${state.teams[team].correctCount}/${state.question.requiredAnswers}</p></div>`;
  document.body.appendChild(overlay);setTimeout(()=>overlay.remove(),3500);
}
function tickRender(){
  const el=document.querySelector("#mainTimer"), meter=document.querySelector("#screenMeter");
  if(!el||!state||!state.deadlineAt)return;
  const ms=state.phase==="paused"?state.remainingMs:Math.max(0,state.deadlineAt-Date.now());
  el.textContent=state.phase==="steal"?"🔥 "+formatMs(ms):formatMs(ms);
  const total=(state.phase==="steal"?state.config.stealSeconds:state.config.roundSeconds)*1000;
  meter.style.width=Math.max(0,Math.min(100,ms/total*100))+"%";
  el.classList.toggle("warning",ms<=10000&&ms>5000);el.classList.toggle("danger",ms<=5000);
  if(ms<=0 && ["running","steal"].includes(state.phase) && lastExpiredDeadline !== state.deadlineAt){
    lastExpiredDeadline=state.deadlineAt; call("advanceExpired",{gameId}).catch(()=>{});
  }
}
if(!gameId){root.innerHTML=`<section class="hero-card glass"><h1>⚠️</h1><p>افتح رابط الشاشة من لوحة المنظم.</p></section>`}
else ensureAuth().then(()=>listenGame(gameId,s=>{state=s;render();clearInterval(tick);tick=setInterval(tickRender,100);}))
  .catch(()=>{root.innerHTML=`<section class="hero-card glass"><h1>⚠️</h1><p>تعذر الاتصال بـ Firebase. تأكد من الإعدادات.</p></section>`});
