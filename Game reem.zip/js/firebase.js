
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.18.0/firebase-app.js";
import { getDatabase, ref, onValue } from "https://www.gstatic.com/firebasejs/12.18.0/firebase-database.js";
import { getAuth, signInAnonymously } from "https://www.gstatic.com/firebasejs/12.18.0/firebase-auth.js";
import { getFunctions, httpsCallable } from "https://www.gstatic.com/firebasejs/12.18.0/firebase-functions.js";
import { firebaseConfig } from "./firebase-config.js";

export const app = initializeApp(firebaseConfig);
export const db = getDatabase(app);
export const auth = getAuth(app);
export const functions = getFunctions(app, "us-central1");
export const gameRef = (gameId) => ref(db, `games/${gameId}`);
export const listenGame = (gameId, callback) => onValue(gameRef(gameId), snap => callback(snap.val()));
export async function ensureAuth() {
  if (!auth.currentUser) await signInAnonymously(auth);
  return auth.currentUser;
}
export const call = (name, data) => httpsCallable(functions, name)(data);
