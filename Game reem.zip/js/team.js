
import { ensureAuth, listenGame, call } from "./firebase.js";
import { escapeHtml } from "./common.js";
const p=new URLSearchParams(location.search), gameId=p.get("game"), team=p.get("team"), token=p.get("token");
const badge=document.querySelector("#teamBadge"), title=document.querySelector("#teamTitle"), joinCard=document.querySelector("#joinCard"), playCard=document.querySelector("#playCard"), waitCard=document.querySelector("#waitCard");
const qEl=document.querySelector("#teamQuestion"), countEl=document.querySelector("#teamCount"), listEl=document.querySelector("#answersList"), form=document.querySelector("#answerForm"), input=document.querySelector("#answerInput"), send=document.querySelector("#sendBtn"), feedback=document.querySelector("#feedback"), timerEl=document.querySelector("#mobileTimer"), roundEl=document.querySelector("#roundLabel"), toast=document.querySelector("#toast");
let state=null,lastRound=null,timer,lastExpiredDeadline=0;
const labels={blue:"🟦",red:"🟥"};
function toastMsg(m){toast.textContent=m;toast.classList.add("show");setTimeout(()=>toast.classList.remove("show"),1800)}
function render(){
  if(!state)return;
  const cfg=state.config, me=state.teams?.[team]; if(!me)return;
  badge.textContent=labels[team]; title.textContent=cfg[team+"Name"];
  const running=["running","steal"].includes(state.phase);
  joinCard.classList.toggle("hidden",running);
  playCard.classList.toggle("hidden",!running);
  waitCard.classList.toggle("hidden",running||state.phase==="lobby");
  if(state.phase==="finished"){joinCard.classList.remove("hidden");playCard.classList.add("hidden");waitCard.classList.add("hidden");document.querySelector("#joinStatus").textContent=`🏁 انتهت اللعبة — ${cfg.blueName} ${state.scores.blue} : ${state.scores.red} ${cfg.redName}`;return;}
  if(state.phase==="lobby"){document.querySelector("#joinStatus").textContent="🟢 متصل — بانتظار البداية";}
  if(state.phase==="paused"){document.querySelector("#waitTitle").textContent="⏸️ الجولة متوقفة";document.querySelector("#waitText").textContent="انتظر استكمال الجولة من المنظم."}
  else if(state.phase==="round_over"){document.querySelector("#waitTitle").textContent=state.winnerTeam?`🏆 ${cfg[state.winnerTeam+"Name"]} فاز`:"⏱️ انتهى الوقت";document.querySelector("#waitText").textContent="انتظر الجولة التالية."}
  else if(state.phase==="finished"){document.querySelector("#waitTitle").textContent="🏁 انتهت اللعبة";document.querySelector("#waitText").textContent=`النتيجة: ${cfg.blueName} ${state.scores.blue} — ${state.scores.red} ${cfg.redName}`;}
  if(running){
    qEl.textContent=state.question.question;countEl.textContent=me.correctCount||0;roundEl.textContent=`الجولة ${state.round}`;
    listEl.innerHTML=Object.values(me.answers||{}).map(a=>`<div class="mobile-answer ${a.correct?"":"bad"}"><span>${a.correct?"✅":"❌"}</span><span>${escapeHtml(a.display||"")}</span></div>`).join("");
    const disabled=state.phase==="steal"&&state.stealTeam!==team || (me.correctCount||0)>=state.question.requiredAnswers;
    send.disabled=disabled;input.disabled=disabled;
    if(disabled)input.placeholder=(me.correctCount||0)>=state.question.requiredAnswers?"اكتمل التحدي":"ليست فرصتك الآن";
  }
}
async function sendAnswer(e){
  e.preventDefault();const text=input.value.trim();if(!text)return;
  send.disabled=true;feedback.className="feedback";feedback.textContent="⏳";
  try{
    const res=await call("submitAnswer",{gameId,team,token,answer:text});
    const d=res.data;
    feedback.className=`feedback ${d.correct?"good":"bad"}`;
    feedback.textContent=d.correct?"✅ إجابة صحيحة!":d.duplicate?"⚠️ هذه الإجابة مكررة":`❌ ${d.message||"إجابة غير صحيحة"}`;
    if(d.correct)input.value=""; else input.select();
  }catch(err){feedback.className="feedback bad";feedback.textContent="⚠️ "+(err.message||"تعذر الإرسال");}
  finally{if(state){const me=state.teams[team];send.disabled=state.phase==="steal"&&state.stealTeam!==team || (me?.correctCount||0)>=5;}setTimeout(()=>feedback.textContent="",1800)}
}
function tickTimer(){
  if(!state||!["running","steal"].includes(state.phase))return;
  const ms=Math.max(0,(state.deadlineAt||0)-Date.now());timerEl.textContent=(ms/1000).toFixed(ms<10000?1:0);
  if(ms<=0){
    timerEl.textContent="0";
    if(lastExpiredDeadline!==state.deadlineAt){lastExpiredDeadline=state.deadlineAt;call("advanceExpired",{gameId}).catch(()=>{});}
  }
}
form.addEventListener("submit",sendAnswer);
(async()=>{
 try{await ensureAuth();}catch(e){toastMsg("تعذر الاتصال بـ Firebase");return}
 if(!gameId||!team||!token||!["blue","red"].includes(team)){toastMsg("رابط الفريق غير صالح");return}
 listenGame(gameId,s=>{state=s;render();if(lastRound!==s?.round){lastRound=s?.round;feedback.textContent=""}});
 timer=setInterval(tickTimer,100);
})();
