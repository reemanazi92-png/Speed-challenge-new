export const QUESTIONS = [
  {
    "id": 1,
    "question": "اذكر 5 فواكه",
    "category": "طعام",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "تفاح",
      "موز",
      "برتقال",
      "عنب",
      "فراولة",
      "مانجو",
      "بطيخ",
      "كيوي",
      "أناناس",
      "رمان",
      "خوخ",
      "كمثرى",
      "بابايا",
      "مشمش",
      "جوافة"
    ]
  },
  {
    "id": 2,
    "question": "اذكر 5 خضروات",
    "category": "طعام",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "طماطم",
      "خيار",
      "جزر",
      "بطاطس",
      "باذنجان",
      "كوسا",
      "بروكلي",
      "قرنبيط",
      "سبانخ",
      "خس",
      "فلفل",
      "بامية",
      "ذرة",
      "فاصوليا",
      "بصل"
    ]
  },
  {
    "id": 3,
    "question": "اذكر 5 أدوات تستخدم في الطبخ",
    "category": "طعام",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "ملعقة",
      "شوكة",
      "سكين",
      "مقلاة",
      "قدر",
      "مصفاة",
      "مبشرة",
      "مضرب",
      "ملقط",
      "لوح تقطيع",
      "مغرفة",
      "فتاحة علب"
    ]
  },
  {
    "id": 4,
    "question": "اذكر 5 أكلات شعبية عربية",
    "category": "طعام",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "كبسة",
      "مندي",
      "مقلوبة",
      "منسف",
      "كشري",
      "ملوخية",
      "جريش",
      "قرصان",
      "ثريد",
      "مضغوط",
      "فتة",
      "محشي"
    ]
  },
  {
    "id": 5,
    "question": "اذكر 5 مشروبات باردة",
    "category": "طعام",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "عصير برتقال",
      "ليمونادة",
      "شاي مثلج",
      "حليب",
      "سموذي",
      "عصير تفاح",
      "عصير مانجو",
      "عصير رمان",
      "مشروب شعير",
      "ماء جوز الهند"
    ]
  },
  {
    "id": 6,
    "question": "اذكر 5 حلويات",
    "category": "طعام",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "كنافة",
      "بقلاوة",
      "كيك",
      "دونات",
      "آيس كريم",
      "مهلبية",
      "لقيمات",
      "تشيز كيك",
      "براوني",
      "قطايف",
      "بسبوسة"
    ]
  },
  {
    "id": 7,
    "question": "اذكر 5 أطعمة يمكن تناولها في الفطور",
    "category": "طعام",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "بيض",
      "جبن",
      "خبز",
      "فول",
      "فلافل",
      "لبنة",
      "تمر",
      "شوفان",
      "مربى",
      "فطائر"
    ]
  },
  {
    "id": 8,
    "question": "اذكر 5 توابل أو بهارات",
    "category": "طعام",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "كمون",
      "قرفة",
      "هيل",
      "كركم",
      "فلفل أسود",
      "زعتر",
      "زنجبيل",
      "قرنفل",
      "سماق",
      "بابريكا",
      "كزبرة ناشفة"
    ]
  },
  {
    "id": 9,
    "question": "اذكر 5 أطعمة تبدأ بحرف م",
    "category": "طعام",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "موز",
      "مانجو",
      "مكرونة",
      "ملوخية",
      "مندي",
      "مقلوبة",
      "مهلبية",
      "مشمش",
      "مكسرات",
      "مربى"
    ]
  },
  {
    "id": 10,
    "question": "اذكر 5 أشياء توضع في السلطة",
    "category": "طعام",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "خيار",
      "طماطم",
      "خس",
      "جزر",
      "ذرة",
      "زيتون",
      "بصل",
      "فلفل",
      "جرجير",
      "فجل",
      "نعناع"
    ]
  },
  {
    "id": 11,
    "question": "اذكر 5 دول عربية",
    "category": "جغرافيا",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "السعودية",
      "الإمارات",
      "الكويت",
      "البحرين",
      "قطر",
      "عمان",
      "العراق",
      "الأردن",
      "مصر",
      "المغرب",
      "الجزائر",
      "تونس",
      "ليبيا",
      "سوريا",
      "لبنان",
      "اليمن"
    ]
  },
  {
    "id": 12,
    "question": "اذكر 5 عواصم عربية",
    "category": "جغرافيا",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "الرياض",
      "أبوظبي",
      "الدوحة",
      "الكويت",
      "مسقط",
      "المنامة",
      "بغداد",
      "عمّان",
      "القاهرة",
      "الرباط",
      "تونس",
      "الجزائر",
      "بيروت",
      "دمشق"
    ]
  },
  {
    "id": 13,
    "question": "اذكر 5 دول تبدأ بحرف أ",
    "category": "جغرافيا",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "أستراليا",
      "ألبانيا",
      "أفغانستان",
      "ألمانيا",
      "أرمينيا",
      "أذربيجان",
      "أوروغواي"
    ]
  },
  {
    "id": 14,
    "question": "اذكر 5 دول تبدأ بحرف م",
    "category": "جغرافيا",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "مصر",
      "ماليزيا",
      "مالطا",
      "مالي",
      "مدغشقر",
      "المغرب",
      "موريتانيا",
      "موزمبيق",
      "منغوليا",
      "ميانمار"
    ]
  },
  {
    "id": 15,
    "question": "اذكر 5 مدن سعودية",
    "category": "جغرافيا",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "الرياض",
      "جدة",
      "الدمام",
      "الخبر",
      "الطائف",
      "مكة",
      "المدينة",
      "أبها",
      "تبوك",
      "حائل",
      "جازان",
      "نجران"
    ]
  },
  {
    "id": 16,
    "question": "اذكر 5 مدن عربية",
    "category": "جغرافيا",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "الرياض",
      "جدة",
      "دبي",
      "أبوظبي",
      "القاهرة",
      "الإسكندرية",
      "عمّان",
      "بيروت",
      "الدوحة",
      "مسقط",
      "الرباط",
      "تونس"
    ]
  },
  {
    "id": 17,
    "question": "اذكر 5 دول في آسيا",
    "category": "جغرافيا",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "السعودية",
      "اليابان",
      "الصين",
      "الهند",
      "كوريا الجنوبية",
      "إندونيسيا",
      "ماليزيا",
      "تايلاند",
      "باكستان",
      "الفلبين"
    ]
  },
  {
    "id": 18,
    "question": "اذكر 5 دول في أوروبا",
    "category": "جغرافيا",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "فرنسا",
      "ألمانيا",
      "إيطاليا",
      "إسبانيا",
      "البرتغال",
      "اليونان",
      "النرويج",
      "السويد",
      "سويسرا",
      "هولندا"
    ]
  },
  {
    "id": 19,
    "question": "اذكر 5 دول في أفريقيا",
    "category": "جغرافيا",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "مصر",
      "المغرب",
      "الجزائر",
      "تونس",
      "كينيا",
      "نيجيريا",
      "إثيوبيا",
      "غانا",
      "جنوب أفريقيا",
      "تنزانيا"
    ]
  },
  {
    "id": 20,
    "question": "اذكر 5 دول تطل على البحر المتوسط",
    "category": "جغرافيا",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "مصر",
      "ليبيا",
      "تونس",
      "الجزائر",
      "المغرب",
      "إسبانيا",
      "فرنسا",
      "إيطاليا",
      "اليونان",
      "تركيا",
      "لبنان",
      "سوريا"
    ]
  },
  {
    "id": 21,
    "question": "اذكر 5 أسماء بنات تبدأ بحرف م",
    "category": "أسماء بنات",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "مريم",
      "منى",
      "مها",
      "مي",
      "منال",
      "ملاك",
      "مرام",
      "مودة",
      "ميس",
      "ميرا",
      "مرح",
      "مهاة"
    ]
  },
  {
    "id": 22,
    "question": "اذكر 5 أسماء بنات تبدأ بحرف ث",
    "category": "أسماء بنات",
    "difficulty": "hard",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "ثناء",
      "ثريا",
      "ثراء",
      "ثمينة",
      "ثويبة",
      "ثقة"
    ]
  },
  {
    "id": 23,
    "question": "اذكر 5 أسماء بنات تبدأ بحرف ن",
    "category": "أسماء بنات",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "نور",
      "ندى",
      "نهى",
      "نورة",
      "نوال",
      "نجوى",
      "نجلاء",
      "نسمة",
      "نغم",
      "نوف"
    ]
  },
  {
    "id": 24,
    "question": "اذكر 5 أسماء بنات تبدأ بحرف س",
    "category": "أسماء بنات",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "سارة",
      "سمر",
      "سلمى",
      "سما",
      "سعاد",
      "سوسن",
      "سحر",
      "سلوى",
      "سناء"
    ]
  },
  {
    "id": 25,
    "question": "اذكر 5 أسماء بنات تبدأ بحرف ر",
    "category": "أسماء بنات",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "ريم",
      "ريما",
      "رنا",
      "رانيا",
      "رؤى",
      "رغد",
      "رزان",
      "روان",
      "رحاب"
    ]
  },
  {
    "id": 26,
    "question": "اذكر 5 أسماء بنات تبدأ بحرف ل",
    "category": "أسماء بنات",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "ليان",
      "لينا",
      "ليلى",
      "لمى",
      "لجين",
      "لارا",
      "لانا",
      "لؤلؤة",
      "لمياء"
    ]
  },
  {
    "id": 27,
    "question": "اذكر 5 أسماء بنات تبدأ بحرف ج",
    "category": "أسماء بنات",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "جود",
      "جنى",
      "جمانة",
      "جميلة",
      "جواهر"
    ]
  },
  {
    "id": 28,
    "question": "اذكر 5 أسماء بنات تبدأ بحرف د",
    "category": "أسماء بنات",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "دانا",
      "دعاء",
      "دانية",
      "دلال",
      "ديمة",
      "دارين",
      "درة"
    ]
  },
  {
    "id": 29,
    "question": "اذكر 5 أسماء بنات تبدأ بحرف أ",
    "category": "أسماء بنات",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "أمل",
      "أسماء",
      "أروى",
      "أريج",
      "آمنة",
      "أفنان",
      "أحلام",
      "أثير",
      "إيمان",
      "ابتسام"
    ]
  },
  {
    "id": 30,
    "question": "اذكر 5 أسماء بنات تبدأ بحرف ف",
    "category": "أسماء بنات",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "فاطمة",
      "فريدة",
      "فرح",
      "فجر",
      "فدوى",
      "فيروز",
      "فلك",
      "فوزية"
    ]
  },
  {
    "id": 31,
    "question": "اذكر 5 أسماء أولاد تبدأ بحرف م",
    "category": "أسماء أولاد",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "محمد",
      "ماجد",
      "مازن",
      "مالك",
      "مراد",
      "مصعب",
      "معاذ",
      "مروان",
      "منصور",
      "مهند"
    ]
  },
  {
    "id": 32,
    "question": "اذكر 5 أسماء أولاد تبدأ بحرف س",
    "category": "أسماء أولاد",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "سامي",
      "سالم",
      "سعد",
      "سلمان",
      "سيف",
      "سليمان",
      "سليم",
      "ساري",
      "سامر"
    ]
  },
  {
    "id": 33,
    "question": "اذكر 5 أسماء أولاد تبدأ بحرف ع",
    "category": "أسماء أولاد",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "عمر",
      "علي",
      "عبدالله",
      "عبدالعزيز",
      "عادل",
      "عاصم",
      "عمار",
      "عاطف",
      "عدنان"
    ]
  },
  {
    "id": 34,
    "question": "اذكر 5 أسماء أولاد تبدأ بحرف أ",
    "category": "أسماء أولاد",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "أحمد",
      "أنس",
      "أيمن",
      "أمين",
      "أكرم",
      "أسامة",
      "أدهم",
      "إياد",
      "إبراهيم"
    ]
  },
  {
    "id": 35,
    "question": "اذكر 5 أسماء أولاد تبدأ بحرف ر",
    "category": "أسماء أولاد",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "راشد",
      "رامي",
      "رائد",
      "ريان",
      "رؤوف",
      "رعد",
      "ربيع",
      "راغب"
    ]
  },
  {
    "id": 36,
    "question": "اذكر 5 أسماء أولاد تبدأ بحرف ن",
    "category": "أسماء أولاد",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "ناصر",
      "نايف",
      "نبيل",
      "نواف",
      "نوح",
      "نادر",
      "نبراس"
    ]
  },
  {
    "id": 37,
    "question": "اذكر 5 أسماء أولاد تبدأ بحرف ف",
    "category": "أسماء أولاد",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "فهد",
      "فيصل",
      "فارس",
      "فواز",
      "فؤاد",
      "فريد",
      "فراس"
    ]
  },
  {
    "id": 38,
    "question": "اذكر 5 أسماء أولاد تبدأ بحرف ي",
    "category": "أسماء أولاد",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "ياسر",
      "يزيد",
      "يوسف",
      "يحيى",
      "يعقوب",
      "يامن"
    ]
  },
  {
    "id": 39,
    "question": "اذكر 5 حيوانات تبدأ بحرف س",
    "category": "حيوانات",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "سمكة",
      "سلحفاة",
      "سنجاب",
      "سمندل",
      "سحلية",
      "سردين"
    ]
  },
  {
    "id": 40,
    "question": "اذكر 5 حيوانات تبدأ بحرف أ",
    "category": "حيوانات",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "أسد",
      "أرنب",
      "أيل",
      "أخطبوط",
      "أفعى",
      "أوزة"
    ]
  },
  {
    "id": 41,
    "question": "اذكر 5 حيوانات تبدأ بحرف ف",
    "category": "حيوانات",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "فيل",
      "فهد",
      "فأر",
      "فلامنغو",
      "فقمة",
      "فرس النهر"
    ]
  },
  {
    "id": 42,
    "question": "اذكر 5 حيوانات بحرية",
    "category": "حيوانات",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "دلفين",
      "حوت",
      "قرش",
      "أخطبوط",
      "فقمة",
      "سلحفاة بحرية",
      "فرس البحر",
      "نجم البحر",
      "سرطان البحر"
    ]
  },
  {
    "id": 43,
    "question": "اذكر 5 حيوانات مفترسة",
    "category": "حيوانات",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "أسد",
      "نمر",
      "فهد",
      "ذئب",
      "ضبع",
      "تمساح",
      "دب",
      "وشق"
    ]
  },
  {
    "id": 44,
    "question": "اذكر 5 حيوانات تعيش في الصحراء",
    "category": "حيوانات",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "جمل",
      "ثعلب صحراوي",
      "عقرب",
      "سحلية",
      "أرنب بري",
      "يربوع",
      "ضب",
      "غزال"
    ]
  },
  {
    "id": 45,
    "question": "اذكر 5 طيور",
    "category": "حيوانات",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "نسر",
      "صقر",
      "حمامة",
      "بومة",
      "ببغاء",
      "عصفور",
      "بط",
      "إوز",
      "نعامة"
    ]
  },
  {
    "id": 46,
    "question": "اذكر 5 حشرات",
    "category": "حيوانات",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "نملة",
      "نحلة",
      "فراشة",
      "ذبابة",
      "بعوضة",
      "جرادة",
      "خنفساء",
      "دعسوقة"
    ]
  },
  {
    "id": 47,
    "question": "اذكر 5 حيوانات أليفة",
    "category": "حيوانات",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "قطة",
      "كلب",
      "أرنب",
      "هامستر",
      "سمكة",
      "طائر",
      "سلحفاة"
    ]
  },
  {
    "id": 48,
    "question": "اذكر 5 أشياء نراها في السماء",
    "category": "طبيعة",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "شمس",
      "قمر",
      "نجوم",
      "سحب",
      "طائرة",
      "قوس قزح",
      "برق"
    ]
  },
  {
    "id": 49,
    "question": "اذكر 5 مصادر للماء",
    "category": "طبيعة",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "نهر",
      "بحر",
      "محيط",
      "بحيرة",
      "بئر",
      "مطر",
      "ينبوع"
    ]
  },
  {
    "id": 50,
    "question": "اذكر 5 ظواهر طبيعية",
    "category": "طبيعة",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "زلازل",
      "براكين",
      "أمطار",
      "برق",
      "رعد",
      "كسوف",
      "خسوف",
      "قوس قزح"
    ]
  },
  {
    "id": 51,
    "question": "اذكر 5 أنواع من الأشجار",
    "category": "طبيعة",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "نخيل",
      "زيتون",
      "ليمون",
      "برتقال",
      "تفاح",
      "سدر",
      "أرز",
      "صنوبر"
    ]
  },
  {
    "id": 52,
    "question": "اذكر 5 أشياء في الغابة",
    "category": "طبيعة",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "أشجار",
      "أوراق",
      "حيوانات",
      "أنهار",
      "صخور",
      "فطر",
      "طيور"
    ]
  },
  {
    "id": 53,
    "question": "اذكر 5 أشياء ترتبط بالبحر",
    "category": "طبيعة",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "موج",
      "رمل",
      "سفينة",
      "سمك",
      "شاطئ",
      "مرجان",
      "صدف",
      "منارة"
    ]
  },
  {
    "id": 54,
    "question": "اذكر 5 رياضات جماعية",
    "category": "رياضة",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "كرة القدم",
      "كرة السلة",
      "كرة الطائرة",
      "كرة اليد",
      "الهوكي",
      "الرجبي"
    ]
  },
  {
    "id": 55,
    "question": "اذكر 5 رياضات فردية",
    "category": "رياضة",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "التنس",
      "السباحة",
      "الجري",
      "الملاكمة",
      "الجودو",
      "الرماية",
      "الجمباز"
    ]
  },
  {
    "id": 56,
    "question": "اذكر 5 أدوات رياضية",
    "category": "رياضة",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "كرة",
      "مضرب",
      "شبكة",
      "خوذة",
      "قفاز",
      "حبل",
      "بساط",
      "مرمى"
    ]
  },
  {
    "id": 57,
    "question": "اذكر 5 رياضات تبدأ بحرف ت",
    "category": "رياضة",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "تنس",
      "تايكوندو",
      "تزلج",
      "تجديف",
      "ترامبولين"
    ]
  },
  {
    "id": 58,
    "question": "اذكر 5 أشياء في ملعب كرة القدم",
    "category": "رياضة",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "مرمى",
      "كرة",
      "شبكة",
      "حكم",
      "مدرجات",
      "خطوط الملعب",
      "راية"
    ]
  },
  {
    "id": 59,
    "question": "اذكر 5 ألعاب أولمبية",
    "category": "رياضة",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "السباحة",
      "الجودو",
      "التنس",
      "الملاكمة",
      "ألعاب القوى",
      "رفع الأثقال",
      "الجمباز"
    ]
  },
  {
    "id": 60,
    "question": "اذكر 5 ألعاب فيديو",
    "category": "ترفيه",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "ماينكرافت",
      "روبلوكس",
      "فيفا",
      "ماريو",
      "فورتنايت",
      "سونيك",
      "تتريس",
      "بوكيمون"
    ]
  },
  {
    "id": 61,
    "question": "اذكر 5 ألعاب جماعية في المنزل",
    "category": "ترفيه",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "مونوبولي",
      "أونو",
      "شطرنج",
      "لودو",
      "جنجفة",
      "سلم وثعبان",
      "جاكارو"
    ]
  },
  {
    "id": 62,
    "question": "اذكر 5 أشياء تستخدم في اللعب",
    "category": "ترفيه",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "كرة",
      "دمية",
      "بطاقات",
      "نرد",
      "لوح لعب",
      "مضرب",
      "حبل"
    ]
  },
  {
    "id": 63,
    "question": "اذكر 5 أنواع من الألعاب",
    "category": "ترفيه",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "ألغاز",
      "سباق",
      "مغامرات",
      "رياضة",
      "استراتيجية",
      "محاكاة",
      "ألعاب ورق"
    ]
  },
  {
    "id": 64,
    "question": "اذكر 5 شخصيات كرتونية مشهورة",
    "category": "ترفيه",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "ميكي ماوس",
      "توم",
      "جيري",
      "سبونج بوب",
      "دورا",
      "بوكيمون",
      "سكوبي دو"
    ]
  },
  {
    "id": 65,
    "question": "اذكر 5 أنواع من الفنون",
    "category": "فن وثقافة",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "الرسم",
      "النحت",
      "التصوير",
      "المسرح",
      "السينما",
      "الخط",
      "الموسيقى"
    ]
  },
  {
    "id": 66,
    "question": "اذكر 5 آلات موسيقية",
    "category": "فن وثقافة",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "عود",
      "بيانو",
      "كمان",
      "جيتار",
      "ناي",
      "طبلة",
      "قانون",
      "تشيللو"
    ]
  },
  {
    "id": 67,
    "question": "اذكر 5 أنواع من الكتب",
    "category": "فن وثقافة",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "رواية",
      "شعر",
      "سيرة",
      "تاريخ",
      "علوم",
      "قصص",
      "موسوعة"
    ]
  },
  {
    "id": 68,
    "question": "اذكر 5 أشياء توجد في المسرح",
    "category": "فن وثقافة",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "ستارة",
      "مقاعد",
      "خشبة",
      "إضاءة",
      "ميكروفون",
      "ممثلون",
      "كواليس"
    ]
  },
  {
    "id": 69,
    "question": "اذكر 5 ألوان",
    "category": "فن وثقافة",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "أحمر",
      "أزرق",
      "أخضر",
      "أصفر",
      "برتقالي",
      "بنفسجي",
      "وردي",
      "أسود",
      "أبيض",
      "بني"
    ]
  },
  {
    "id": 70,
    "question": "اذكر 5 كواكب في النظام الشمسي",
    "category": "علوم",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "عطارد",
      "الزهرة",
      "الأرض",
      "المريخ",
      "المشتري",
      "زحل",
      "أورانوس",
      "نبتون"
    ]
  },
  {
    "id": 71,
    "question": "اذكر 5 أجزاء من جسم الإنسان",
    "category": "علوم",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "قلب",
      "دماغ",
      "رئة",
      "معدة",
      "كبد",
      "يد",
      "قدم",
      "عين",
      "أذن"
    ]
  },
  {
    "id": 72,
    "question": "اذكر 5 حواس",
    "category": "علوم",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "البصر",
      "السمع",
      "الشم",
      "الذوق",
      "اللمس"
    ]
  },
  {
    "id": 73,
    "question": "اذكر 5 مصادر للطاقة",
    "category": "علوم",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "الشمس",
      "الرياح",
      "الماء",
      "النفط",
      "الغاز",
      "الفحم",
      "الحرارة الجوفية"
    ]
  },
  {
    "id": 74,
    "question": "اذكر 5 مواد صلبة",
    "category": "علوم",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "حديد",
      "خشب",
      "زجاج",
      "حجر",
      "بلاستيك",
      "ذهب",
      "نحاس"
    ]
  },
  {
    "id": 75,
    "question": "اذكر 5 أشياء تجذبها المغناطيسات",
    "category": "علوم",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "حديد",
      "مسمار حديد",
      "مشبك ورق",
      "فولاذ",
      "دبوس",
      "مسمار"
    ]
  },
  {
    "id": 76,
    "question": "اذكر 5 أجهزة إلكترونية",
    "category": "تقنية",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "هاتف",
      "حاسوب",
      "جهاز لوحي",
      "تلفاز",
      "ساعة ذكية",
      "سماعة",
      "كاميرا"
    ]
  },
  {
    "id": 77,
    "question": "اذكر 5 تطبيقات للتواصل",
    "category": "تقنية",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "واتساب",
      "تيليجرام",
      "سناب شات",
      "إنستغرام",
      "ديسكورد",
      "سيجنال"
    ]
  },
  {
    "id": 78,
    "question": "اذكر 5 أجزاء من الحاسوب",
    "category": "تقنية",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "شاشة",
      "لوحة مفاتيح",
      "فأرة",
      "معالج",
      "ذاكرة",
      "قرص تخزين",
      "سماعات"
    ]
  },
  {
    "id": 79,
    "question": "اذكر 5 متصفحات إنترنت",
    "category": "تقنية",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "كروم",
      "سفاري",
      "فايرفوكس",
      "إيدج",
      "أوبرا",
      "بريف"
    ]
  },
  {
    "id": 80,
    "question": "اذكر 5 أشياء تستخدمها في الإنترنت",
    "category": "تقنية",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "متصفح",
      "محرك بحث",
      "بريد إلكتروني",
      "كلمة مرور",
      "رابط",
      "حساب"
    ]
  },
  {
    "id": 81,
    "question": "اذكر 5 أشياء تجدها في المدرسة",
    "category": "مدرسة",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "سبورة",
      "كتب",
      "طاولات",
      "كراسي",
      "أقلام",
      "معلم",
      "طلاب",
      "حقيبة"
    ]
  },
  {
    "id": 82,
    "question": "اذكر 5 مواد دراسية",
    "category": "مدرسة",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "رياضيات",
      "علوم",
      "لغة عربية",
      "لغة إنجليزية",
      "تاريخ",
      "جغرافيا",
      "فنون",
      "حاسوب"
    ]
  },
  {
    "id": 83,
    "question": "اذكر 5 أدوات مدرسية",
    "category": "مدرسة",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "قلم",
      "ممحاة",
      "مسطرة",
      "دفتر",
      "مقص",
      "مبراة",
      "ألوان",
      "حقيبة"
    ]
  },
  {
    "id": 84,
    "question": "اذكر 5 أماكن في المدرسة",
    "category": "مدرسة",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "فصل",
      "مكتبة",
      "مختبر",
      "ملعب",
      "مقصف",
      "مسرح",
      "إدارة"
    ]
  },
  {
    "id": 85,
    "question": "اذكر 5 أشياء في حقيبة الطالب",
    "category": "مدرسة",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "كتاب",
      "دفتر",
      "قلم",
      "ممحاة",
      "مسطرة",
      "مقلمة",
      "آلة حاسبة"
    ]
  },
  {
    "id": 86,
    "question": "اذكر 5 أشياء تستخدم في السفر",
    "category": "سفر",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "جواز سفر",
      "حقيبة",
      "تذكرة",
      "هاتف",
      "شاحن",
      "ملابس",
      "خريطة",
      "نقود"
    ]
  },
  {
    "id": 87,
    "question": "اذكر 5 وسائل نقل للسفر",
    "category": "سفر",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "طائرة",
      "قطار",
      "سيارة",
      "حافلة",
      "سفينة",
      "عبّارة"
    ]
  },
  {
    "id": 88,
    "question": "اذكر 5 أشياء تجدها في المطار",
    "category": "سفر",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "بوابة",
      "طائرة",
      "جوازات",
      "أمتعة",
      "صالة انتظار",
      "مقهى",
      "شاشة رحلات"
    ]
  },
  {
    "id": 89,
    "question": "اذكر 5 أشياء تأخذها إلى الفندق",
    "category": "سفر",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "ملابس",
      "هاتف",
      "شاحن",
      "فرشاة أسنان",
      "حقيبة",
      "جواز سفر"
    ]
  },
  {
    "id": 90,
    "question": "اذكر 5 أماكن سياحية",
    "category": "سفر",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "برج",
      "متحف",
      "قلعة",
      "شاطئ",
      "حديقة",
      "سوق قديم",
      "موقع أثري"
    ]
  },
  {
    "id": 91,
    "question": "اذكر 5 أسماء من سور القرآن",
    "category": "إسلام",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "الفاتحة",
      "البقرة",
      "يس",
      "الكهف",
      "الرحمن",
      "الملك",
      "الإخلاص",
      "الفلق",
      "الناس"
    ]
  },
  {
    "id": 92,
    "question": "اذكر 5 من أركان الإسلام",
    "category": "إسلام",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "الشهادتان",
      "الصلاة",
      "الزكاة",
      "الصوم",
      "الحج"
    ]
  },
  {
    "id": 93,
    "question": "اذكر 5 من أركان الإيمان",
    "category": "إسلام",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "الإيمان بالله",
      "ملائكته",
      "كتبه",
      "رسله",
      "اليوم الآخر",
      "القدر"
    ]
  },
  {
    "id": 94,
    "question": "اذكر 5 أسماء لأنبياء",
    "category": "إسلام",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "آدم",
      "نوح",
      "إبراهيم",
      "موسى",
      "عيسى",
      "محمد",
      "يوسف",
      "يونس",
      "داود",
      "سليمان"
    ]
  },
  {
    "id": 95,
    "question": "اذكر 5 عبادات",
    "category": "إسلام",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "الصلاة",
      "الصوم",
      "الزكاة",
      "الحج",
      "الدعاء",
      "الذكر",
      "قراءة القرآن"
    ]
  },
  {
    "id": 96,
    "question": "اذكر 5 أشياء موجودة في المنزل",
    "category": "حياة يومية",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "أريكة",
      "تلفاز",
      "ثلاجة",
      "سرير",
      "طاولة",
      "كرسي",
      "ستارة",
      "سجادة"
    ]
  },
  {
    "id": 97,
    "question": "اذكر 5 أشياء تستخدمها صباحًا",
    "category": "حياة يومية",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "فرشاة أسنان",
      "معجون",
      "منشفة",
      "صابون",
      "مشط",
      "حقيبة",
      "هاتف"
    ]
  },
  {
    "id": 98,
    "question": "اذكر 5 أشياء في الحمام",
    "category": "حياة يومية",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "مرآة",
      "صابون",
      "منشفة",
      "فرشاة أسنان",
      "حوض",
      "دش",
      "شامبو"
    ]
  },
  {
    "id": 99,
    "question": "اذكر 5 أشياء في غرفة النوم",
    "category": "حياة يومية",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "سرير",
      "وسادة",
      "خزانة",
      "مرآة",
      "مصباح",
      "ستارة",
      "بطانية"
    ]
  },
  {
    "id": 100,
    "question": "اذكر 5 أشياء تساعد على التنظيم",
    "category": "حياة يومية",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "جدول",
      "قائمة",
      "تقويم",
      "منبه",
      "ملفات",
      "صناديق تخزين",
      "ملاحظات"
    ]
  },
  {
    "id": 101,
    "question": "اذكر 5 أشياء موجودة في السيارة",
    "category": "سيارات ومواصلات",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "مقود",
      "مقعد",
      "مرآة",
      "حزام أمان",
      "عجلة",
      "مكيف",
      "راديو",
      "فرامل"
    ]
  },
  {
    "id": 102,
    "question": "اذكر 5 أنواع من وسائل النقل",
    "category": "سيارات ومواصلات",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "سيارة",
      "حافلة",
      "قطار",
      "طائرة",
      "سفينة",
      "دراجة",
      "دراجة نارية"
    ]
  },
  {
    "id": 103,
    "question": "اذكر 5 أشياء في الشارع",
    "category": "سيارات ومواصلات",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "إشارة مرور",
      "رصيف",
      "سيارات",
      "ممر مشاة",
      "إنارة",
      "محلات",
      "مواقف"
    ]
  },
  {
    "id": 104,
    "question": "اذكر 5 أشياء يحتاجها السائق",
    "category": "سيارات ومواصلات",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "رخصة",
      "مفتاح",
      "حزام أمان",
      "مرآة",
      "وقود",
      "خريطة",
      "هاتف"
    ]
  },
  {
    "id": 105,
    "question": "اذكر 5 مهن",
    "category": "مهن",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "طبيب",
      "معلم",
      "مهندس",
      "ممرض",
      "محاسب",
      "محامي",
      "طباخ",
      "مصمم"
    ]
  },
  {
    "id": 106,
    "question": "اذكر 5 مهن تبدأ بحرف م",
    "category": "مهن",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "معلم",
      "ممرض",
      "محاسب",
      "مصور",
      "مترجم",
      "مخرج"
    ]
  },
  {
    "id": 107,
    "question": "اذكر 5 مهن تعمل في المستشفى",
    "category": "مهن",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "طبيب",
      "ممرض",
      "صيدلي",
      "جراح",
      "فني مختبر",
      "أخصائي أشعة"
    ]
  },
  {
    "id": 108,
    "question": "اذكر 5 مهن تستخدم الحاسوب كثيرًا",
    "category": "مهن",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "مبرمج",
      "مصمم",
      "محاسب",
      "كاتب",
      "محرر",
      "مهندس",
      "مترجم"
    ]
  },
  {
    "id": 109,
    "question": "اذكر 5 أشياء لونها أبيض غالبًا",
    "category": "ألوان وأشياء",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "ثلج",
      "ورق",
      "حليب",
      "ملح",
      "قميص",
      "سحابة",
      "طباشير"
    ]
  },
  {
    "id": 110,
    "question": "اذكر 5 أشياء لونها أخضر غالبًا",
    "category": "ألوان وأشياء",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "عشب",
      "أوراق",
      "خيار",
      "بروكلي",
      "شجرة",
      "تفاح أخضر"
    ]
  },
  {
    "id": 111,
    "question": "اذكر 5 أشياء دائرية",
    "category": "ألوان وأشياء",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "كرة",
      "ساعة",
      "طبق",
      "عملة",
      "عجلة",
      "قرص",
      "حلقة"
    ]
  },
  {
    "id": 112,
    "question": "اذكر 5 أشياء لها أزرار",
    "category": "ألوان وأشياء",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "قميص",
      "ريموت",
      "آلة حاسبة",
      "هاتف",
      "لوحة مفاتيح",
      "مصعد"
    ]
  },
  {
    "id": 113,
    "question": "اذكر 5 أطعمة يمكن أكلها بدون طبخ",
    "category": "طعام إضافي",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "تفاح",
      "موز",
      "تمر",
      "خيار",
      "جزر",
      "عنب",
      "برتقال",
      "فراولة"
    ]
  },
  {
    "id": 114,
    "question": "اذكر 5 أطعمة تحفظ في الثلاجة",
    "category": "طعام إضافي",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "حليب",
      "جبن",
      "زبادي",
      "عصير",
      "خضروات",
      "فواكه",
      "بيض"
    ]
  },
  {
    "id": 115,
    "question": "اذكر 5 أشياء تستخدم عند إعداد الكيك",
    "category": "طعام إضافي",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "دقيق",
      "بيض",
      "سكر",
      "زبدة",
      "حليب",
      "وعاء",
      "مضرب",
      "قالب"
    ]
  },
  {
    "id": 116,
    "question": "اذكر 5 دول تبدأ بحرف ب",
    "category": "جغرافيا إضافية",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "بحرين",
      "بلجيكا",
      "بنما",
      "بنغلاديش",
      "باكستان",
      "بولندا",
      "بيرو",
      "بوتان"
    ]
  },
  {
    "id": 117,
    "question": "اذكر 5 دول تبدأ بحرف ك",
    "category": "جغرافيا إضافية",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "كندا",
      "كوبا",
      "كينيا",
      "كوريا الجنوبية",
      "كوريا الشمالية",
      "كولومبيا",
      "كرواتيا",
      "كمبوديا"
    ]
  },
  {
    "id": 118,
    "question": "اذكر 5 مدن عالمية مشهورة",
    "category": "جغرافيا إضافية",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "لندن",
      "باريس",
      "نيويورك",
      "طوكيو",
      "دبي",
      "روما",
      "إسطنبول",
      "مدريد"
    ]
  },
  {
    "id": 119,
    "question": "اذكر 5 دول جزرية",
    "category": "جغرافيا إضافية",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "اليابان",
      "الفلبين",
      "إندونيسيا",
      "آيسلندا",
      "مالديف",
      "مدغشقر",
      "نيوزيلندا"
    ]
  },
  {
    "id": 120,
    "question": "اذكر 5 أسماء بنات تبدأ بحرف ح",
    "category": "أسماء",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "حنان",
      "حلا",
      "حور",
      "حوراء",
      "حياة",
      "حفصة",
      "حمدة"
    ]
  },
  {
    "id": 121,
    "question": "اذكر 5 أسماء بنات تبدأ بحرف ع",
    "category": "أسماء",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "عائشة",
      "عبير",
      "علا",
      "عهود",
      "عفاف",
      "عذراء",
      "عنود"
    ]
  },
  {
    "id": 122,
    "question": "اذكر 5 أسماء أولاد تبدأ بحرف ح",
    "category": "أسماء",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "حسن",
      "حسين",
      "حمد",
      "حسام",
      "حاتم",
      "حمزة",
      "حازم"
    ]
  },
  {
    "id": 123,
    "question": "اذكر 5 أسماء أولاد تبدأ بحرف ك",
    "category": "أسماء",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "كريم",
      "كمال",
      "كاظم",
      "كامل",
      "كنان",
      "كاسر"
    ]
  },
  {
    "id": 124,
    "question": "اذكر 5 حيوانات تبدأ بحرف ب",
    "category": "حيوانات إضافية",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "بقرة",
      "بطة",
      "ببغاء",
      "بجعة",
      "باندا",
      "بوم"
    ]
  },
  {
    "id": 125,
    "question": "اذكر 5 حيوانات تبدأ بحرف ن",
    "category": "حيوانات إضافية",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "نمر",
      "نعامة",
      "نحلة",
      "نسر",
      "ناقة",
      "نورس"
    ]
  },
  {
    "id": 126,
    "question": "اذكر 5 حيوانات لها قرون",
    "category": "حيوانات إضافية",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "غزال",
      "ماعز",
      "بقرة",
      "خروف",
      "وحيد القرن",
      "أيل"
    ]
  },
  {
    "id": 127,
    "question": "اذكر 5 أنواع من الزهور",
    "category": "طبيعة إضافية",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "ورد",
      "ياسمين",
      "زنبق",
      "توليب",
      "بنفسج",
      "نرجس",
      "قرنفل"
    ]
  },
  {
    "id": 128,
    "question": "اذكر 5 أشياء يمكن العثور عليها على الشاطئ",
    "category": "طبيعة إضافية",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "رمل",
      "صدف",
      "حجر",
      "طحالب",
      "ماء",
      "خشب",
      "قارب"
    ]
  },
  {
    "id": 129,
    "question": "اذكر 5 ألوان في قوس قزح",
    "category": "طبيعة إضافية",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "أحمر",
      "برتقالي",
      "أصفر",
      "أخضر",
      "أزرق",
      "نيلي",
      "بنفسجي"
    ]
  },
  {
    "id": 130,
    "question": "اذكر 5 رياضات تبدأ بحرف ك",
    "category": "رياضة إضافية",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "كرة القدم",
      "كرة السلة",
      "كرة اليد",
      "كرة الطائرة",
      "كاراتيه",
      "كريكيت"
    ]
  },
  {
    "id": 131,
    "question": "اذكر 5 أشياء يستخدمها لاعب كرة القدم",
    "category": "رياضة إضافية",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "كرة",
      "حذاء",
      "قميص",
      "شورت",
      "جوارب",
      "واقي الساق"
    ]
  },
  {
    "id": 132,
    "question": "اذكر 5 بطولات أو مسابقات رياضية معروفة",
    "category": "رياضة إضافية",
    "difficulty": "hard",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "كأس العالم",
      "دوري الأبطال",
      "ويمبلدون",
      "الألعاب الأولمبية",
      "كأس آسيا",
      "رولان غاروس"
    ]
  },
  {
    "id": 133,
    "question": "اذكر 5 أنواع من الأفلام",
    "category": "فن وثقافة إضافية",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "كوميديا",
      "أكشن",
      "دراما",
      "خيال علمي",
      "رعب",
      "وثائقي",
      "رسوم متحركة"
    ]
  },
  {
    "id": 134,
    "question": "اذكر 5 أشياء يستخدمها الرسام",
    "category": "فن وثقافة إضافية",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "فرشاة",
      "ألوان",
      "قلم",
      "لوحة",
      "ممحاة",
      "مسطرة"
    ]
  },
  {
    "id": 135,
    "question": "اذكر 5 أماكن ثقافية",
    "category": "فن وثقافة إضافية",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "متحف",
      "مكتبة",
      "مسرح",
      "معرض",
      "مركز ثقافي",
      "موقع أثري"
    ]
  },
  {
    "id": 136,
    "question": "اذكر 5 أشياء تحتاجها النباتات للنمو",
    "category": "علوم إضافية",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "ماء",
      "ضوء",
      "هواء",
      "تربة",
      "أملاح معدنية"
    ]
  },
  {
    "id": 137,
    "question": "اذكر 5 حالات للمادة",
    "category": "علوم إضافية",
    "difficulty": "hard",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "صلبة",
      "سائلة",
      "غازية",
      "بلازما"
    ]
  },
  {
    "id": 138,
    "question": "اذكر 5 أعضاء أو أجزاء داخل جسم الإنسان",
    "category": "علوم إضافية",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "قلب",
      "رئتان",
      "كبد",
      "معدة",
      "كليتان",
      "دماغ",
      "أمعاء"
    ]
  },
  {
    "id": 139,
    "question": "اذكر 5 أجهزة يمكن توصيلها بالبلوتوث",
    "category": "تقنية إضافية",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "سماعة",
      "هاتف",
      "لوحة مفاتيح",
      "فأرة",
      "ساعة ذكية",
      "سيارة"
    ]
  },
  {
    "id": 140,
    "question": "اذكر 5 أنواع من الملفات الرقمية",
    "category": "تقنية إضافية",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "PDF",
      "صورة",
      "فيديو",
      "صوت",
      "نص",
      "جدول بيانات"
    ]
  },
  {
    "id": 141,
    "question": "اذكر 5 خدمات أو أدوات تخزين سحابي",
    "category": "تقنية إضافية",
    "difficulty": "hard",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "Google Drive",
      "iCloud",
      "OneDrive",
      "Dropbox",
      "Box"
    ]
  },
  {
    "id": 142,
    "question": "اذكر 5 أشياء يفعلها الطالب في الفصل",
    "category": "مدرسة إضافية",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "يقرأ",
      "يكتب",
      "يستمع",
      "يجيب",
      "يسأل",
      "يرسم"
    ]
  },
  {
    "id": 143,
    "question": "اذكر 5 أشياء في المختبر المدرسي",
    "category": "مدرسة إضافية",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "مجهر",
      "أنابيب اختبار",
      "نظارات حماية",
      "ميزان",
      "كؤوس مخبرية",
      "قفازات"
    ]
  },
  {
    "id": 144,
    "question": "اذكر 5 أشياء يحتاجها المعلم",
    "category": "مدرسة إضافية",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "كتاب",
      "سبورة",
      "قلم",
      "حاسوب",
      "خطة درس",
      "أوراق"
    ]
  },
  {
    "id": 145,
    "question": "اذكر 5 أشياء قد تحتاجها في رحلة بحرية",
    "category": "سفر إضافي",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "سترة نجاة",
      "ماء",
      "قبعة",
      "حقيبة",
      "هاتف",
      "واقي شمس"
    ]
  },
  {
    "id": 146,
    "question": "اذكر 5 أنواع من أماكن الإقامة",
    "category": "سفر إضافي",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "فندق",
      "شقة فندقية",
      "منتجع",
      "نزل",
      "مخيم",
      "فيلا"
    ]
  },
  {
    "id": 147,
    "question": "اذكر 5 أشياء تفعلها قبل السفر",
    "category": "سفر إضافي",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "حجز التذكرة",
      "تجهيز الحقيبة",
      "فحص الجواز",
      "تحديد الفندق",
      "شحن الهاتف",
      "تجهيز المال"
    ]
  },
  {
    "id": 148,
    "question": "اذكر 5 أسماء لشهور هجرية",
    "category": "إسلام إضافي",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "محرم",
      "صفر",
      "رمضان",
      "شوال",
      "ذو الحجة",
      "رجب",
      "شعبان"
    ]
  },
  {
    "id": 149,
    "question": "اذكر 5 أعمال صالحة",
    "category": "إسلام إضافي",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "الصدقة",
      "بر الوالدين",
      "الصلاة",
      "الصيام",
      "مساعدة المحتاج",
      "صلة الرحم",
      "الذكر"
    ]
  },
  {
    "id": 150,
    "question": "اذكر 5 مساجد مشهورة",
    "category": "إسلام إضافي",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "المسجد الحرام",
      "المسجد النبوي",
      "المسجد الأقصى",
      "جامع الأزهر",
      "مسجد قباء"
    ]
  },
  {
    "id": 151,
    "question": "اذكر 5 أشياء تستخدم للتنظيف",
    "category": "حياة يومية إضافية",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "مكنسة",
      "ممسحة",
      "صابون",
      "منظف",
      "إسفنجة",
      "سلة مهملات"
    ]
  },
  {
    "id": 152,
    "question": "اذكر 5 أشياء تحتاجها قبل النوم",
    "category": "حياة يومية إضافية",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "وسادة",
      "بطانية",
      "منبه",
      "ملابس نوم",
      "ماء",
      "كتاب"
    ]
  },
  {
    "id": 153,
    "question": "اذكر 5 أشياء يمكن شراؤها من السوبرماركت",
    "category": "حياة يومية إضافية",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "حليب",
      "خبز",
      "أرز",
      "ماء",
      "فاكهة",
      "خضروات",
      "مناديل"
    ]
  },
  {
    "id": 154,
    "question": "اذكر 5 أجزاء خارجية للسيارة",
    "category": "سيارات إضافية",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "باب",
      "زجاج",
      "مرآة",
      "مصباح",
      "إطار",
      "غطاء المحرك",
      "صندوق الأمتعة"
    ]
  },
  {
    "id": 155,
    "question": "اذكر 5 إشارات أو علامات في الطريق",
    "category": "سيارات إضافية",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "قف",
      "ممنوع الدخول",
      "ممر مشاة",
      "حد السرعة",
      "دوار",
      "إشارة مرور"
    ]
  },
  {
    "id": 156,
    "question": "اذكر 5 وسائل نقل داخل المدينة",
    "category": "سيارات إضافية",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "سيارة",
      "حافلة",
      "تاكسي",
      "مترو",
      "قطار",
      "دراجة",
      "دراجة كهربائية"
    ]
  },
  {
    "id": 157,
    "question": "اذكر 5 مهن إبداعية",
    "category": "مهن إضافية",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "مصمم",
      "كاتب",
      "مصور",
      "رسام",
      "مخرج",
      "موسيقي",
      "محرر"
    ]
  },
  {
    "id": 158,
    "question": "اذكر 5 مهن تعمل في البناء",
    "category": "مهن إضافية",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "مهندس",
      "معماري",
      "نجار",
      "حداد",
      "كهربائي",
      "سباك",
      "عامل بناء"
    ]
  },
  {
    "id": 159,
    "question": "اذكر 5 مهن تخدم الناس مباشرة",
    "category": "مهن إضافية",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "طبيب",
      "معلم",
      "ممرض",
      "شرطي",
      "موظف خدمة",
      "سائق",
      "بائع"
    ]
  },
  {
    "id": 160,
    "question": "اذكر 5 أشياء لا تنسى أخذها إلى الشاطئ",
    "category": "أسئلة مفاجئة",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "منشفة",
      "ماء",
      "قبعة",
      "واقي شمس",
      "ملابس إضافية",
      "حقيبة",
      "نظارة شمسية"
    ]
  },
  {
    "id": 161,
    "question": "اذكر 5 أشياء يمكن أن تكون صغيرة وكبيرة",
    "category": "أسئلة مفاجئة",
    "difficulty": "hard",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "حقيبة",
      "كرة",
      "سيارة",
      "طاولة",
      "كتاب",
      "صندوق",
      "شاشة"
    ]
  },
  {
    "id": 162,
    "question": "اذكر 5 أشياء تصدر صوتًا",
    "category": "أسئلة مفاجئة",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "هاتف",
      "جرس",
      "سيارة",
      "منبه",
      "تلفاز",
      "بيانو",
      "صافرة"
    ]
  },
  {
    "id": 163,
    "question": "اذكر 5 أشياء يمكن أن تكون ساخنة",
    "category": "أسئلة مفاجئة",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "شاي",
      "قهوة",
      "شوربة",
      "فرن",
      "شمس",
      "ماء",
      "طعام"
    ]
  },
  {
    "id": 164,
    "question": "اذكر 5 أشياء لها مفتاح",
    "category": "أسئلة مفاجئة",
    "difficulty": "medium",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "باب",
      "سيارة",
      "خزانة",
      "حاسوب",
      "قفل",
      "بيانو"
    ]
  },
  {
    "id": 165,
    "question": "اذكر 5 أشياء يمكن حملها باليد",
    "category": "أسئلة مفاجئة",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "كتاب",
      "هاتف",
      "قلم",
      "كوب",
      "حقيبة",
      "كرة",
      "مظلة"
    ]
  },
  {
    "id": 166,
    "question": "اذكر 5 أشياء تبدأ بحرف ك",
    "category": "أسئلة مفاجئة",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "كتاب",
      "كرسي",
      "كوب",
      "كرة",
      "كيس",
      "كاميرا",
      "كعكة"
    ]
  },
  {
    "id": 167,
    "question": "اذكر 5 أشياء تبدأ بحرف ب",
    "category": "أسئلة مفاجئة",
    "difficulty": "easy",
    "requiredAnswers": 5,
    "acceptedAnswers": [
      "باب",
      "بيت",
      "بطانية",
      "براد",
      "بسكويت",
      "بالون",
      "بطارية"
    ]
  }
];
