
import { ensureAuth, listenGame, call } from "./firebase.js";
import { QUESTIONS } from "./questions.js";
import { escapeHtml } from "./common.js";

const $=s=>document.querySelector(s), toast=$("#toast");
let state=null,gameId=null,adminPin="",tick;
function toastMsg(m){toast.textContent=m;toast.classList.add("show");setTimeout(()=>toast.classList.remove("show"),2200)}
function roundsValue(){return $("#rounds").value==="custom"?Number($("#customRounds").value):Number($("#rounds").value)}
$("#rounds").addEventListener("change",e=>$("#customRoundsWrap").classList.toggle("hidden",e.target.value!=="custom"));
$("#createGameBtn").addEventListener("click",async()=>{
  adminPin=$("#adminPin").value.trim(); if(!adminPin){showError("اكتب رمز المنظم.");return}
  const payload={adminPin,config:{blueName:$("#blueName").value.trim()||"الفريق الأول",redName:$("#redName").value.trim()||"الفريق الثاني",blueColor:$("#blueColor").value,redColor:$("#redColor").value,rounds:roundsValue(),roundSeconds:Number($("#roundSeconds").value),stealSeconds:Number($("#stealSeconds").value),difficulty:$("#difficulty").value,sound:$("#sound").checked}};
  try{await ensureAuth();const r=await call("createGame",payload);gameId=r.data.gameId;sessionStorage.setItem("speedGameId",gameId);sessionStorage.setItem("adminPin",adminPin);$("#setupPanel").classList.add("hidden");$("#controlPanel").classList.remove("hidden");listenGame(gameId,s=>{state=s;render();});toastMsg("تم إنشاء اللعبة");}
  catch(e){showError(e.message||"تعذر إنشاء اللعبة")}
});
function showError(m){$("#setupError").textContent=m;$("#setupError").classList.remove("hidden")}
function action(name,extra={}){return call("adminCommand",{gameId,adminPin,action:name,...extra}).catch(e=>{toastMsg(e.message||"تعذر تنفيذ الأمر");throw e})}
$("#startBtn").onclick=()=>action("start");
$("#nextBtn").onclick=()=>action("next");
$("#pauseBtn").onclick=()=>action("pause");
$("#resumeBtn").onclick=()=>action("resume");
$("#resetRoundBtn").onclick=()=>action("resetRound");
$("#skipBtn").onclick=()=>action("skip");
$("#endBtn").onclick=()=>action("endRound");
$("#resetGameBtn").onclick=()=>{if(confirm("إعادة ضبط اللعبة بالكامل؟"))action("resetGame")};
document.querySelectorAll("[data-score]").forEach(b=>b.onclick=()=>action("adjustScore",{team:b.dataset.score,delta:Number(b.dataset.delta)}));
$("#saveQuestionBtn").onclick=async()=>{
  const answers=$("#customAnswers").value.split(",").map(x=>x.trim()).filter(Boolean);
  const q={id:Number($("#editQuestionId").value)||undefined,question:$("#customQuestion").value,category:$("#customCategory").value,difficulty:$("#customDifficulty").value,acceptedAnswers:answers};
  if(!q.question.trim()||answers.length<5){toastMsg("أدخل السؤال و5 إجابات مقبولة على الأقل.");return}
  try{await action(q.id?"updateQuestion":"addQuestion",{question:q});clearQuestionForm();toastMsg(q.id?"تم تعديل السؤال":"تمت إضافة السؤال");}catch{}
};
$("#cancelEditBtn").onclick=clearQuestionForm;
function clearQuestionForm(){$("#editQuestionId").value="";$("#customQuestion").value="";$("#customCategory").value="";$("#customAnswers").value="";$("#customDifficulty").value="medium";$("#saveQuestionBtn").textContent="➕ إضافة سؤال";$("#cancelEditBtn").classList.add("hidden");}

document.querySelectorAll(".copy-btn").forEach(b=>b.onclick=async()=>{const team=b.dataset.copy;const t=state.teams[team];const url=`${location.origin}${location.pathname.replace(/admin\.html$/,"")}team.html?game=${gameId}&team=${team}&token=${encodeURIComponent(t.token)}`;await navigator.clipboard.writeText(url);toastMsg("تم نسخ رابط الفريق")});
$("#bankSearch").addEventListener("input",renderBank);$("#bankFilter").addEventListener("change",renderBank);
function render(){
  if(!state)return;
  $("#gameIdLabel").textContent=`غرفة: ${gameId}`;
  $("#phaseLabel").textContent=state.phase.toUpperCase();
  $("#blueNameOut").textContent=state.config.blueName;$("#redNameOut").textContent=state.config.redName;
  $("#blueScore").textContent=state.scores.blue;$("#redScore").textContent=state.scores.red;
  $("#roundOut").textContent=state.round?`الجولة ${state.round} من ${state.config.rounds}`:"لم تبدأ";
  $("#questionOut").textContent=state.question?.question||"اضغط «بدء اللعبة»";
  $("#qrBlueTitle").textContent=state.config.blueName;$("#qrRedTitle").textContent=state.config.redName;
  $("#stateBlueName").textContent=state.config.blueName;$("#stateRedName").textContent=state.config.redName;
  updateTeam("blue");updateTeam("red");renderQR();
  $("#startBtn").disabled=!(state.phase==="lobby"||state.phase==="round_over");
  $("#nextBtn").disabled=!(state.phase==="round_over"||state.phase==="lobby");
  $("#pauseBtn").disabled=state.phase!=="running";$("#resumeBtn").disabled=state.phase!=="paused";
  $("#resetRoundBtn").disabled=!state.question||state.phase==="lobby";
  $("#skipBtn").disabled=!["running","paused","steal"].includes(state.phase);$("#endBtn").disabled=!["running","paused","steal"].includes(state.phase);
  $("#bankCount").textContent=`${QUESTIONS.length} سؤال مدمج — الأسئلة المستخدمة: ${(state.usedQuestions||[]).length}`;
}
function updateTeam(team){
 const t=state.teams[team],need=state.question?.requiredAnswers||5,c=t?.correctCount||0;
 $(`#state${team==="blue"?"Blue":"Red"}Count`).textContent=`${c} / ${need}`;
 $(`#state${team==="blue"?"Blue":"Red"}Bar`).style.width=(c/need*100)+"%";
 const el=$(`#state${team==="blue"?"Blue":"Red"}Status`);
 if(state.winnerTeam===team)el.textContent="🏆 فاز";else if(state.phase==="steal"&&state.stealTeam===team)el.textContent="🔥 فرصة السرقة";else if(state.phase==="running")el.textContent=c?`🔵 يجيب — ${c}/${need}`:"🟢 في انتظار الإجابة";else if(state.phase==="paused")el.textContent="⏸️ متوقفة";else el.textContent=state.phase==="round_over"?"❌ انتهت الجولة":"🟢 في الانتظار";
}
function renderQR(){
 if(!window.QRCode||!state)return;
 for(const team of ["blue","red"]){
   const box=$("#qr"+(team==="blue"?"Blue":"Red"));box.innerHTML="";
   const url=`${location.origin}${location.pathname.replace(/admin\.html$/,"")}team.html?game=${gameId}&team=${team}&token=${encodeURIComponent(state.teams[team].token)}`;
   new QRCode(box,{text:url,width:120,height:120,colorDark:"#101625",colorLight:"#ffffff",correctLevel:QRCode.CorrectLevel.M});
 }
}
function renderBank(){
 const search=$("#bankSearch").value.trim().toLowerCase(), filter=$("#bankFilter").value;
 const custom=state?.customQuestions||[];
 const combined=[...QUESTIONS,...custom].filter(q=>(!filter||q.difficulty===filter)&&(!search||q.question.toLowerCase().includes(search)||q.category.toLowerCase().includes(search))).slice(0,160);
 $("#bankList").innerHTML=combined.map(q=>{
   const isCustom=custom.some(c=>c.id===q.id);
   return `<article class="bank-item"><span class="diff">${q.difficulty==="easy"?"🟢":q.difficulty==="medium"?"🟡":"🔴"}</span><b>${q.id}. ${escapeHtml(q.question)}</b><small>${escapeHtml(q.category)} · ${q.acceptedAnswers.length} إجابة مقبولة</small>${isCustom?`<div class="item-actions"><button class="ghost-btn" data-edit="${q.id}">✏️ تعديل</button><button class="danger-btn" data-delete="${q.id}">🗑️ حذف</button></div>`:""}</article>`
 }).join("");
 document.querySelectorAll("[data-edit]").forEach(b=>b.onclick=()=>editCustom(Number(b.dataset.edit)));
 document.querySelectorAll("[data-delete]").forEach(b=>b.onclick=async()=>{if(confirm("حذف هذا السؤال؟")){await action("deleteQuestion",{questionId:Number(b.dataset.delete)});}});

}
function editCustom(id){
 const q=(state.customQuestions||[]).find(x=>x.id===id);if(!q)return;
 $("#editQuestionId").value=q.id;$("#customQuestion").value=q.question;$("#customCategory").value=q.category;$("#customDifficulty").value=q.difficulty;$("#customAnswers").value=q.acceptedAnswers.join(", ");
 $("#saveQuestionBtn").textContent="💾 حفظ التعديل";$("#cancelEditBtn").classList.remove("hidden");window.scrollTo({top:document.body.scrollHeight,behavior:"smooth"});
}
function tickTimer(){
 if(!state||!["running","steal","paused"].includes(state.phase))return;
 const ms=state.phase==="paused"?state.remainingMs:Math.max(0,(state.deadlineAt||0)-Date.now());
 const sec=ms/1000;$("#timerOut").textContent=sec<10?sec.toFixed(1):Math.ceil(sec);
 const total=(state.phase==="steal"?state.config.stealSeconds:state.config.roundSeconds)*1000;$("#timerMeter").style.width=Math.max(0,Math.min(100,ms/total*100))+"%";
}
const saved=sessionStorage.getItem("speedGameId"), savedPin=sessionStorage.getItem("adminPin");
if(saved&&savedPin){gameId=saved;adminPin=savedPin;$("#setupPanel").classList.add("hidden");$("#controlPanel").classList.remove("hidden");ensureAuth().then(()=>listenGame(gameId,s=>{state=s;render()})).catch(()=>{});}
else renderBank();
setInterval(tickTimer,100);
renderBank();
