# ⚡ تحدي السرعة

لعبة مسابقات مباشرة لفريقين، مبنية على:
- GitHub Pages للواجهة.
- Firebase Realtime Database للمزامنة اللحظية.
- Firebase Cloud Functions للتحقق من الإجابات، الوقت، الفوز، السرقة، والنقاط من جهة الخادم.
- Firebase Anonymous Auth لهوية جلسة الجهاز.
- QR Code منفصل لكل فريق.
- 167 سؤالًا عربيًا مدمجًا، مع عدة إجابات مقبولة لكل سؤال.

## الملفات

```text
index.html                 شاشة العرض الكبيرة
team.html                  شاشة الفريق على الجوال
admin.html                 لوحة المنظم
css/style.css              التصميم
js/firebase-config.js      بيانات Firebase الخاصة بك
js/firebase.js             تهيئة Firebase
js/questions.js            بنك الأسئلة (167 سؤالًا)
js/common.js               تطبيع العربية وأدوات عامة
js/screen.js               منطق الشاشة الكبيرة
js/team.js                 منطق شاشة الفريق
js/admin.js                لوحة التحكم
functions/index.js         منطق الخادم الآمن
functions/questions.js     نسخة بنك الأسئلة للخادم
functions/package.json     تبعيات Cloud Functions
firebase.json              إعداد Firebase
database.rules.json        قواعد القراءة/الكتابة
```

## 1) إنشاء Firebase

1. افتح Firebase Console وأنشئ مشروعًا جديدًا.
2. أضف Web App للمشروع.
3. فعّل **Realtime Database**.
4. فعّل **Authentication → Sign-in method → Anonymous**.
5. انسخ إعدادات Web App وضعها داخل:
   `js/firebase-config.js`

> لا تغيّر شكل الملف، فقط استبدل القيم التي تبدأ بـ `YOUR_`.

## 2) تثبيت Firebase CLI

ثبّت Node.js 22، ثم:

```bash
npm install -g firebase-tools
firebase login
```

من داخل مجلد المشروع:

```bash
firebase use --add
```

اختر مشروع Firebase الخاص بك.

## 3) وضع PIN المنظم

من داخل مجلد المشروع:

```bash
firebase functions:secrets:set ADMIN_PIN
```

اكتب PIN خاصًا بك عند الطلب.

ثم:

```bash
cd functions
npm install
cd ..
firebase deploy --only functions,database
```

Cloud Functions تحتاج خطة Firebase التي تسمح بتشغيل Functions. راجع شاشة Billing في Firebase إذا طلب منك الترقية.

## 4) تشغيل الواجهة

للتجربة المحلية، استخدم أي خادم HTTP محلي بدل فتح ملفات HTML مباشرة.

مثال:

```bash
python -m http.server 8080
```

ثم افتح:

```text
http://localhost:8080/admin.html
```

أو انشر ملفات الواجهة على GitHub Pages.

## 5) اختبار الفريق الأول والثاني

1. افتح `admin.html`.
2. أدخل PIN المنظم.
3. اضغط «إنشاء اللعبة».
4. ستظهر QR Codes للفريقين.
5. امسح QR الفريق الأول من هاتف.
6. امسح QR الفريق الثاني من هاتف آخر.
7. افتح رابط الشاشة الكبيرة `index.html?game=GAME_ID`.
8. اضغط «بدء اللعبة».
9. جرّب إرسال إجابات من الهاتفين.

كل إجابة تمر عبر Cloud Function وتُقارن بقائمة الإجابات المقبولة في الخادم، ثم تُحدّث Realtime Database فورًا.

## 6) نشر GitHub Pages

ارفع ملفات الواجهة إلى مستودع GitHub:

- `index.html`
- `team.html`
- `admin.html`
- مجلد `css`
- مجلد `js`

ولا تحتاج إلى رفع مجلد `functions` لكي تعمل GitHub Pages، لكنه يجب أن يبقى في مستودعك إذا كنت تريد إدارة المشروع كاملًا في مكان واحد.

من إعدادات المستودع:
**Settings → Pages → Deploy from a branch → main → / (root)**

بعد النشر ستكون الروابط على شكل:

```text
https://USERNAME.github.io/REPOSITORY/admin.html
https://USERNAME.github.io/REPOSITORY/index.html?game=GAME_ID
```

## 7) QR Codes

لا تحتاج إلى إنشاء QR يدويًا.

بعد إنشاء اللعبة، لوحة المنظم تولد:
- QR للفريق الأول.
- QR للفريق الثاني.

كل QR يحمل `gameId + team + token`، لذلك يعرف النظام الفريق تلقائيًا.

## ملاحظات مهمة

- لا تضع `ADMIN_PIN` داخل ملفات JavaScript؛ هو محفوظ في Firebase Secret Manager.
- `firebase-config.js` ليس سرًا بالمعنى التقليدي؛ حماية البيانات الفعلية تأتي من Firebase Rules وCloud Functions.
- لا يستطيع متصفح الفريق الكتابة مباشرة إلى قاعدة البيانات؛ قواعد Realtime Database تمنع الكتابة المباشرة.
- التحقق من الإجابة، منع التكرار، انتهاء الوقت، تحديد الأسرع، السرقة، والنقاط يتم في Cloud Functions.
- التوقيت الأساسي يعتمد على وقت الخادم داخل Cloud Function عند وصول الطلب، وليس على ساعة هاتف اللاعب.
- عند انتهاء وقت الجولة، الشاشة أو جهاز الفريق يستدعي `advanceExpired` مرة واحدة تقريبًا، والخادم هو الذي يقرر الانتقال للسرقة أو نهاية الجولة.
- للحصول على حماية أقوى ضد إساءة استخدام endpoints، يمكن تفعيل Firebase App Check بعد نجاح التشغيل الأساسي.
